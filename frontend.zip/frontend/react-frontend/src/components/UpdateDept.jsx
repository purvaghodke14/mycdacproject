import React, { Component } from 'react';
import DepService from '../services/DepService';

class UpdateDept extends Component {
    constructor(props){
        super(props)

        this.state={
            id:this.props.match.params.id,
            deptName:'',
            deptContactNo:''
        }
        this.changeDeptIdHandler=this.changeDeptIdHandler.bind(this);
        this.changedeptNameHandler=this.changedeptNameHandler.bind(this);
        this.changedeptContactNoHandler=this.changedeptContactNoHandler.bind(this);
        this.updateDept=this.updateDept.bind(this);
    }
    componentDidMount(){
    
    DepService.getDeptById(this.state.id).then((res) =>{
            let depts=res.data;
            this.setState({
               deptName:depts.deptName,
               deptContactNo:depts.deptContactNo

            })
            

        });
    }
    updateDept=(e) => {
        e.preventDefault();

        let depts={deptName:this.state.deptName,deptContactNo:this.state.deptContactNo};
        console.log('depts =>'+ JSON.stringify(depts));
        
       DepService.updateDept(depts,this.state.id).then(res=>{
        this.props.history.push('/dept');
       
    });
}
changeDeptIdHandler= (event)=>{
    this.setState({id:event.target.value});
}

changedeptNameHandler= (event)=>{
    this.setState({deptName:event.target.value});
}
changedeptContactNoHandler= (event)=>{
    this.setState({deptContactNo:event.target.value});
}
cancel(){
    this.props.history.push('/dept');

}


    render() {
        return (
            <div>
            <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h3 className="text-center">Update Department Details</h3>
                        
                        <div className="card-body">
                        <form>
                        
                        <div className="form-group">
                                <label>Dept Id:</label>
                                <input placeholder="Dept Id" name="id" className="form-control" value={this.state.id} onChange={this.changeDeptIdHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Department Name:</label>
                                <input placeholder="Department Name" name="deptName" className="form-control" value={this.state.deptName} onChange={this.changedeptNameHandler}/>
                            </div>

                            
                            <div className="form-group">
                                <label>Contact No:</label>
                                <input placeholder="Contact No" name="deptContactNo" className="form-control" value={this.state.deptContactNo} onChange={this.changedeptContactNoHandler}/>
                            </div>
                            
                            <button className="btn btn-success" onClick={this.updateDept}>Update</button>
                            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}> Cancel</button>
                        </form>
                        </div>
                    </div>

                </div>
            </div>
            </div>
        );
    }
        
}

export default UpdateDept;