import React, { Component } from 'react';
import Input from "react-validation/build/input";
import  Form from 'react-validation/build/form';
import BirthService from '../services/BirthService';

const required = value => {
    if (!value) {
      return (
        <div className="alert alert-danger" role="alert">
          This field is required!
        </div>
      );
    }
  };
class CreateBirthApp extends Component {
    constructor(props){
        super(props)

        this.state={
            name:'',
            f_name:'',
            mName:'',
            gender:'',
            dateOfBirth:'',
            birth_location:'',
            address:''
        }
        this.changeBNameHandler=this.changeBNameHandler.bind(this);
        this.changeFNameHandler=this.changeFNameHandler.bind(this);
        this.changeMNameHandler=this.changeMNameHandler.bind(this);
        this.changeDOBHandler=this.changeDOBHandler.bind(this);
        this.changeLocationHandler=this.changeLocationHandler.bind(this);
        this.changeAddressHandler=this.changeAddressHandler.bind(this);
        this.cancel=this.cancel.bind(this);
    }
    componentDidMount(){

    
        BirthService.getBirthById(this.state.id).then((res) =>{
            let births=res.data;
            this.setState({ 
                id:births.id,
                name:births.name,
                f_name:births.f_name,
                mName:births.mName,
                gender:births.gender,
                dateOfBirth:births.dateOfBirth,
                birth_location:births.birth_location,
                address:births.address
                
            });

        });
    }
    saveCertificate=(e) => {
        e.preventDefault();

        let births={id:this.state.id,name:this.state.name,f_name:this.state.f_name,mName:this.state.mName,gender:this.state.gender,dateOfBirth:this.state.dateOfBirth,birth_location:this.state.birth_location,address:this.state.address};
        console.log('births =>'+ JSON.stringify(births));

        

        
            BirthService.createCertificate(births).then(res=>{
               window.location="/cerSucc";
            });
        
        

    }
    changeFNameHandler= (event)=>{
        this.setState({f_name:event.target.value});
    }
    changeAddressHandler=(event)=>{
        this.setState({address:event.target.value});
    }
    changeBNameHandler=(event)=>{
        this.setState({name:event.target.value});
    }
    changeMNameHandler=(event)=>{
        this.setState({mName:event.target.value});
    }
    changeDOBHandler=(event)=>{
        this.setState({dateOfBirth:event.target.value});
    }
    changeLocationHandler=(event)=>{
        this.setState({birth_location:event.target.value});
    }
    setGender=(event) =>{
        this.setState({gender:event.target.value});
      }
      cancel(){
        this.props.history.push('/view-citizen');

    }

    render() {
        return (
            <div>
                <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h3 className="text-center">Application form of BirthCertificate</h3>
                        
                        <div className="card-body">
                        <Form>
                        
                        <div className="form-group">
                                <label>Beneficiary Name:</label>
                                <Input placeholder="Beneficiary Name" name="name" className="form-control" value={this.state.name} validations={[required]} onChange={this.changeBNameHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Father Name:</label>
                                <Input placeholder="Father Name" name="f_name" className="form-control" value={this.state.f_name} onChange={this.changeFNameHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Mother Name:</label>
                                <Input placeholder="Mother Name" name="mName" className="form-control" value={this.state.mName} onChange={this.changeMNameHandler}/>
                            </div>
                            
                            
                            <div  class="form-check form-check-inline"  onChange={this.setGender.bind(this)}>
                            <label>Gender:</label>
                                    <Input type="radio" value="MALE" name="gender"/> Male <Input type="radio" value="FEMALE" name="gender"/> Female
                             </div>
                            
                            <div className="form-group">
                                <label> DateOfBirth:</label>
                                <Input type="date" placeholder="DateOfBirth" name="dateOfBirth" className="form-control" value={this.state.dateOfBirth} onChange={this.changeDOBHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Birth Location:</label>
                                <Input placeholder="Birth Location" name="birth_location" className="form-control" value={this.state.birthLocation} onChange={this.changeLocationHandler}/>
                            </div>
                            <div className="form-group">
                                <label>Address:</label>
                                <Input placeholder="Address" name="address" className="form-control" value={this.state.address} onChange={this.changeAddressHandler}/>
                            </div>
                            
                            <button className="btn btn-success" onClick={this.saveCertificate}>Submit</button>
                            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}> Cancel</button>
                        </Form>
                        </div>
                    </div>

                </div>
            </div>
            </div>
        );
    }
}

export default CreateBirthApp;