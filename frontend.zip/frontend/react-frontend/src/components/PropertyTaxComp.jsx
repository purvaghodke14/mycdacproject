import React, { Component } from 'react';
import Input from "react-validation/build/input";
import  Form from 'react-validation/build/form';
import CompService from '../services/PropTax';
import PropTax from '../services/PropTax';
import axios from 'axios';

const required = value => {
    if (!value) {
      return (
        <div className="alert alert-danger" role="alert">
          This field is required!
        </div>
      );
    }
  };

class PropertyTaxComp extends Component {
    constructor(props){
        super(props)

        this.state={
            location:'',
            type:'',
            value:'',
            tax :0.92,
            rate :1.05,
            
            props:[]
          
            
        }
        this.changeValueHandler=this.changeValueHandler.bind(this);
        //this.changelocationHandler=this.changelocationHandler.bind(this);
        //this.changetypeHandler=this.changetypeHandler.bind(this);
        this.saveProceed=this.saveProceed.bind(this);
     
    }



    componentDidMount(){
         PropTax.getPropertyTaxById(this.state.id).then((res) =>{
            let props=res.data;
            this.setState({ 
                  id:props.id,
                 location:props.location,
                type:props.type,
                 value:props.value
           
        });

     });

    }
    saveProceed=(event)=>{
        event.preventDefault();
        
        // let value = this.state.value;
        // let  tax = 0.92;
        // let rate = 1.05;
        //let propertyTax = ((value*tax)/100)*rate;
       // let props={location:this.state.location,type:this.state.type,propertyTax:this.state.propertyTax};
        PropTax.getPropertyTaxById(this.state.id).then((res)=>{
            this.setState({props:res.data});
            });
        
            this.props.history.push('/payment');
      
        //PropTax.getTax(props).then(res=>{
          
   
}

    
    changeValueHandler(event){
        this.setState({value: event.target.value});

     }
    // changelocationHandler(event){
    //     this.setState({value:event.target.value});

    // }
    // changetypeHandler(event){
    //     this.setState({type:event.target.value})
    // }

    
    // handleFormSubmit(event) {

    //         event.preventDefault();
    //          let value = this.state.value;
    //          let  tax = 0.92;
    //          let rate = 1.05;
    //         let propertyTax = ((value*tax)/100)*rate;
    //     // console.log(propertyTax);
    //     // const self = this;
    //     // const fd=new FormData();
    //     //      fd.append('value',value);
    //     //      fd.append('propertyTax',propertyTax);
    //     //      fd.append('location',this.state.location);
           
    //     //      axios.post("http://localhost:8080/api/v1/proptax",fd)
    //     //      .then(response => {
              
    //     //         window.location="http://localhost:8080/api/v1/gettax";
              
    //     //      });

    //     PropTax.getTax(this.state.location,this.state.value,this.state.propertyTax).then(  () => {
              
             
    //         this.props.history.push('/citizens');
    //       },
        
    //     );
    //     } 
  

  
         
      

   
    cancel(){
       this.props.history.push('/view-citizen');

    }

    render() {
        const  value = ((this.state.value * this.state.tax)/100)*this.state.rate;
        return (
            <div>
               <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h3 className="text-center">Pay Property Tax</h3>
                        
                        <div className="card-body">
                        <Form>
               
                        
                        
                           
                            

                            <div className="form-group">
                                <label>location:</label>
                                <Input placeholder="location" name="location" className="form-control" value={this.state.location} validations={[required]} onChange={this.changelocationHandler}/>
                            </div>
                           
                            <div className="form-group">
                                <label>Property Type:</label>
                                <Input  placeholder="Property Type" name="type" className="form-control" value={this.state.type} validations={[required]} onChange={this.changetypeHandler}/>
                            </div>
                            <div className="form-group">
                                <label>Assessed Value:</label>
                                <Input  placeholder="Value" name="Value" className="form-control" value={this.state.Value} validations={[required]} onChange={this.changeValueHandler}/>
                            </div>
                            <div className="form-group">
                                <label>Property Tax:</label>
                                <Input  placeholder="Property Tax" name="value" className="form-control" value={value}  onChange={this.changeValHandler}/>
                            </div>
                            
                            
                            
                               
                                
                               
                                
                            
                                <button className="btn btn-primary" onClick={(event) => this.saveProceed(event)} style={{marginLeft:"10px"}}> Proceed to payment</button>
                            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}> Cancel</button>
                        </Form>
                        </div>
                    </div>

                </div>
            </div> 
            </div>
        );
    }
}

export default PropertyTaxComp;