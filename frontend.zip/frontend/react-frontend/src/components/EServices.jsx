import React, { Component } from 'react';

class EServices extends Component {



    giveComplaint(){
        this.props.history.push('/complaint');
    }
    propTax(){
        this.props.history.push('/proptax')
    }
    birthCertificate(){
        this.props.history.push('/birth');
    }
    deathCertificate(){
      this.props.history.push('/deathcer');
    }
    render() {
        return (
            <div>
                 <button onClick={() => this.giveComplaint()} className="btn btn-info">Give Complaint</button>
                        <button style={{marginLeft:"10px"}}  onClick={() => this.propTax()} className="btn btn-info">Pay Property Tax</button>
                        
                        <button style={{marginLeft:"10px"}} onClick={() => this.birthCertificate()} className="btn btn-info">Apply For BirthCertificate</button>
                        <button style={{marginLeft:"10px"}} onClick={() => this.deathCertificate()} className="btn btn-info">Apply For DeathCertificate</button>
            </div>
        );
    }
}

export default EServices;