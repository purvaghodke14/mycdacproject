import React, { Component } from 'react';

class SuccReg extends Component {
    backDept()
    {
       window.location='/';
    }
    render() {
        return (
            <div>
                You are Successfully registered to website......
                <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To Home</button>
            </div>
        );
    }
}

export default SuccReg;