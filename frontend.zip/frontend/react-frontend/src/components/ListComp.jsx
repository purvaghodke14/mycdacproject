import React, { Component } from 'react';
import CompService from '../services/CompService';

class ListComp extends Component {
    constructor(props){
        super(props)

        this.state={
            id:this.props.match.params.id,
            complaints:[]
        }
        this.delete=this.delete.bind(this);
    }
    componentDidMount(){
        CompService.retriveAllComplaints(this.state.id).then(res=>{
            const data=JSON.stringify(res);
            //console.log(data.data.result);
            const data1=JSON.parse(data);
            console.log(data1.data);
            
            this.setState({
                complaints:data1.data
                
            })
             });
             //console.log(this.state.complaints)
     
         }
    
        
    
   delete()
    {
        this.props.history.push('/citizens');
    }
    render() {
        return (
            <div>
                  <div className="container">
                <h2 className="text-center">Complaint List</h2>
         
                <div className="row">
                    
                <div className="card-body">
                    <table className="table table-striped table-bordered table-dark table-responsive-lg" >
                        <thead>
                            <tr>
                                 <th> Complaint Id </th>
                                <th> Dept Name </th>

                                <th> Complaint </th>
                               
                                

                                 <th>Actions</th>

                           </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.complaints.map (
                                    complaint =>
                                            <tr key={complaint.dept_id}>
                                                 <td>{complaint.id}</td>
                                                <td>{complaint.deptName}</td>
                                                <td>{complaint.complaint}</td>
                                                
                                               
                                                
                                                <td>
                                                <button onClick={() => this.delete()} className="btn btn-danger">Delete</button>
                                                    
                                                </td>
                                            </tr>
                                )  
                                
                            }
                            
                         </tbody>
                    </table>
                    
                    </div>
                </div>
            </div>
            </div>
        );
    }
}

export default ListComp;