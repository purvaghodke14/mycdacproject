import React, { Component } from 'react';
import Input from "react-validation/build/input";
import  Form from 'react-validation/build/form';
import CompService from '../services/CompService'; 

const required = value => {
    if (!value) {
      return (
        <div className="alert alert-danger" role="alert">
          This field is required!
        </div>
      );
    }
  };

class ComplaintsComp extends Component {
    constructor(props){
        super(props)

        this.state={
            id:'',
            complaints:'',
            deptName:''
         
          
            
        }
        
        this.changedeptNameHandler=this.changedeptNameHandler.bind(this);
        this.changecomplaintHandler=this.changecomplaintHandler.bind(this);
        this.saveComplaint=this.saveComplaint.bind(this);
    }
    /*componentDidMount(){

    
        CompService.getComplaintById(this.state.id).then((res) =>{
            let comp=res.data;
            this.setState({ 
            
                name:comp.name,
                emailId:comp.emailId,
                complaints:comp.complaints,
                date:comp.date,
                deptName:comp.deptName

                
            });

        });
    }*/
    
    saveComplaint=(e) => {
        e.preventDefault();

        let citizens=JSON.parse(localStorage.getItem("citizens")).id
        console.log('citizens =>'+this.state.deptName,this.state.complaint);

        
       CompService.createComplaint(citizens,this.state.deptName,this.state.complaint).then(

            ()=>{
                
              
                this.props.history.push('/view-citizen');
        });
        
           
        
        

    }
    

    
    
    changedeptNameHandler= (event)=>{
        this.setState({deptName:event.target.value});
    }
    
    changecomplaintHandler=(event)=>{
        this.setState({complaint:event.target.value});
    }

    cancel(){
        this.props.history.push('/citizens');

    }


    render() {
        return (
            <div>
                <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h3 className="text-center">Complaint</h3>
                        
                        <div className="card-body">
                        <Form>
                        
                        
                           
                            

                            <div className="form-group">
                                <label>Dept Name:</label>
                                <Input placeholder="Dept Name" name="deptName" className="form-control" value={this.state.deptName} validations={[required]} onChange={this.changedeptNameHandler}/>
                            </div>
                           
                            <div className="form-group">
                                <label>Complaint:</label>
                                <Input type="text" placeholder="Complaint" name="complaint" className="form-control" value={this.state.complaint} validations={[required]} onChange={this.changecomplaintHandler}/>
                            </div>
                            
                            <button className="btn btn-success" onClick={this.saveComplaint}>Save</button>
                            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}> Cancel</button>
                        </Form>
                        </div>
                    </div>

                </div>
            </div>
            </div>
        );
    }
}

export default ComplaintsComp;