import React, { Component } from 'react';
import BankService from '../services/BankService';

class ViewPayment extends Component {
    constructor(props){
        super(props)

        this.state={
            bank:[]
        }
        
        //this.allDept=this.allDept.bind(this);
    }
    componentDidMount(){
        BankService.getAllPayment().then((res)=>{
        this.setState({bank:res.data});
      });
    }
      backDept()
      {
          this.props.history.push('/view-admin');
      }

    render() {
        return (
            <div>
                <div className="container">
                <h2 className="text-center">All Taxes Payment List</h2>
                
                <div className="row">
                    
                <div className="card-body">
                    <table className="table table-striped table-bordered table-dark table-responsive-xl" >
                        <thead>
                            <tr>
                                <th> Payment ID </th>

                                <th> Citizen Name </th>

                                <th> Bank Name</th>

                                <th> Branch Name</th>
                                
                                <th> Card Number</th>
                                
                                <th>Card Expiry Date </th>
                                <th>CVV Number</th>
                               
                                <th>Payment Amount </th>
                                
                             

                             
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.bank.map (
                                    payment =>
                                            <tr key={payment.id}>
                                                <td>{payment.id}</td>
                                                <td>{payment.name}</td>
                                                <td>{payment.bankName}</td>
                                                <td>{payment.branchName}</td>
                                                <td>{payment.cardNumber}</td>
                                                <td>{payment.expiryDate}</td>
                                                <td>{payment.cvvNumber}</td>
                                                
                                                <td>{payment.paymentAmount}</td>
                                                <td>
                                                  
                                                   
                                                </td>
                                            </tr>
                                )  
                                
                            }
                            
                         </tbody>
                    </table>
                    <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To Main</button>
                    </div>
                </div>
            </div>
            </div>
        );
    }
}

export default ViewPayment;