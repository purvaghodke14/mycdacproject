import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class HeaderComponents extends Component {
    render() {
        return (
            <div>
              
              <nav className="navbar navbar-expand-sm bg-light">
                    <div><Link to="/">PUNE SMART CITY</Link></div>
                    <div><Link to="/register"><button className="btn btn-primary" type="button" style={{marginLeft:"10px"}}>Register</button></Link></div>
                    <div><Link to="/login"><button className="btn btn-primary" type="button" style={{marginLeft:"10px"}}>UserLogin</button></Link></div>
                    <div><Link to="/admin-login"><button className="btn btn-primary" type="button" style={{marginLeft:"10px"}}>Admin</button></Link></div>
                    </nav>
            
                  
                 
              
                
            </div>
        );
    }
}

export default HeaderComponents;

