import React, { Component } from 'react';

class AboutUs extends Component {
    backDept()
    {
       window.location='/';
    }
    render() {
        return (
            <div>
                <div className="container">
                <h1 style={{backgroundColor: "lightblue"}} >Welcome Citizen</h1>
                    <p>
                The Pune Municipal Corporation is the civic body that governs the inner limits of Pune, India. It is in charge of the civic needs and infrastructure of the metropolis, which is spread over an area of 331.26 sq. km. and has 3.4 million residents. Wikipedia
                </p>
                First election: 1952
                <p>Next election: February 2022 (expected)</p>
                <p>Deputy Mayor: Saraswati Shendge; (BJP)</p>
                <p>Mayor: Murlidhar Mohol (BJP)</p>
                <p> Municipal Commissioner: Vikram Kumar, IAS</p>
                <p>Seats: 162</p>
            </div>
            <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To Home</button>
            </div>
        );
    }
}

export default AboutUs;