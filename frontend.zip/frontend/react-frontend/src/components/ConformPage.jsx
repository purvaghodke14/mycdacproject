import React, { Component } from 'react';

class ConformPage extends Component {
    backDept()
    {
       window.location='/view-citizen';
    }
    render() {
        return (
            <div>
                You are Done Payment successfully ......
                <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To main page</button>
            </div>
        );
    }
}


export default ConformPage;