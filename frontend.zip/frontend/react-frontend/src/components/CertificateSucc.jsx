import React, { Component } from 'react';

class CertificateSucc extends Component {
    backDept()
    {
       window.location='/view-citizen';
    }
    render() {
        return (
            <div>
                <h1>
                Your application submitted successfully ......</h1>
                <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To main page</button>
            </div>
        );
    }
}

export default CertificateSucc;