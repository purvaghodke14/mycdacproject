import React, { Component } from 'react';
import PropTax from '../services/PropTax';

class ViewPropTax extends Component {
    constructor(props){
        super(props)

        this.state={
            propertyTax:[]
        }
        
    }
    componentDidMount(){
        PropTax.getAllTax().then((res)=>{
        this.setState({ propertyTax:res.data});
      });
    }

    render() {
        return (
            <div>
                 <div className="container">
                <h2 className="text-center">Property Tax List</h2>
              
                <div className="row">
                    
                <div className="card-body">
                    <table className="table table-striped table-bordered table-dark table-responsive-lg" >
                        <thead>
                            <tr>
                              

                                <th> Location </th>

                                <th> Type </th>

                                <th> Assessed value</th>
                                <th> Property tax </th>
                                
                                

                                <th>    Actions     </th>
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.propertyTax.map (
                                    props =>
                                            <tr key={props.id}>
                                              
                                                <td>{props.location}</td>
                                                <td>{props.type}</td>
                                                <td>{props.value}</td>
                                                <td>{props.propertyTax}</td>
                                              
                                                <td>
                                                    <button style={{marginLeft:"10px"}} onClick={() => this.viewProps()} className="btn btn-info">View</button>
                                                    
                                                </td>
                                            </tr>
                                )  
                                
                            }
                            
                         </tbody>
                    </table>
                    
                    </div>
                </div>
            </div>
            </div>
        );
    }
}

export default ViewPropTax;