import React, { Component } from 'react';
import DeathService from '../services/DeathService';

class ViewDeathCer extends Component {
    constructor(props){
        super(props)

        this.state={
            deaths:[]
        }
        
        //this.allDept=this.allDept.bind(this);
    }
    componentDidMount(){
        DeathService.getDeath().then((res)=>{
        this.setState({deaths:res.data});
      });
        
    }
    backDept()
    {
        this.props.history.push('/view-admin');
    }
    render() {
        return (
            <div>
                <div className="container">
                <h2 className="text-center">DeathCertificate Application List</h2>
                
                <div className="row">
                    
                <div className="card-body">
                    <table className="table table-striped table-bordered table-dark table-responsive-xl" >
                        <thead>
                            <tr>
                                <th> Certificate ID </th>

                                <th> Deceased Name </th>

                                <th> Deceased Father/Husband Name </th>

                                <th> Deceased Age </th>
                                
                                <th> Deceased date of death </th>
                                
                                <th>Deceased Death location </th>
                                <th>Deceased Gender</th>
                                <th>Deceased Address </th>
                                <th>Deceased Nationality</th>
                                <th>Deceased Religion</th>
                               
                             

                             
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.deaths.map (
                                    death =>
                                            <tr key={death.id}>
                                                <td>{death.id}</td>
                                                <td>{death.name}</td>
                                                <td>{death.f_name}</td>
                                                <td>{death.age}</td>
                                                <td>{death.dateOfDeath}</td>
                                                <td>{death.death_location}</td>
                                                <td>{death.gender}</td>
                                                <td>{death.address}</td>
                                                <td>{death.nationality}</td>
                                                <td>{death.religion}</td>
                                                <td>
                                                  
                                                   
                                                </td>
                                            </tr>
                                )  
                                
                            }
                            
                         </tbody>
                    </table>
                    <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To Main</button>
                    </div>
                </div>
            </div>
            </div>
        );
    }
}

export default ViewDeathCer;