import React, { Component } from 'react';
import DepService from '../services/DepService';
class DeptComponent extends Component {
    constructor(props){
        super(props)

        this.state={
             depts:[] 
           
        }
        this.saveDept=this.saveDept.bind(this);
       this.viewDept=this.viewDept.bind(this);
       this.deleteDept=this.deleteDept.bind(this);
      this.viewComp=this.viewComp.bind(this);
   
    }
    componentDidMount(){

        DepService.getDept().then((res)=>{
        this.setState({depts:res.data});
        });

       
    }
    deleteDept(id){
        DepService.deleteDept(id).then(res =>{
            this.setState({depts:this.state.depts.filter(dept => dept.id !== id)});
        });
    }
    editDept(id){
        this.props.history.push(`/update-dept/${id}`);
    }
    viewDept(id){
        this.props.history.push(`/view/${id}`);
    }
    saveDept(){
        this.props.history.push('/add');
    }
    viewComp(id){
        this.props.history.push(`/getcomplaint/${id}`);
    }
    backDept()
    {
        this.props.history.push('/view-admin');
    }
   
    
    render() {
        return (
            <div>
                <div>
                <h2 className="text-center">Department Of Cities</h2>
                <button className="btn btn-success" onClick={this.saveDept}>Add Departments</button>
                <div className="card-body">
                <div className="row">
                
                
                
                    <table className="table table-striped table-bordered table-dark" >
                        <thead>
                            <tr>
                                <th> Dept ID </th>

                                <th> Department Name</th>

                                <th> Department Contact No </th>

                                <th>    Actions     </th>
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.depts.map (
                                    dept =>
                                            <tr key={dept.id}>
                                                <td>{dept.id}</td>
                                                <td>{dept.deptName}</td>
                                                <td>{dept.deptContactNo}</td>
                                                
                                                
                                                <td>
                                                     
                                                    <button  style={{marginLeft:"10px"}} onClick={() => this.editDept(dept.id)} className="btn btn-info">Update</button>
                                                    <button style={{marginLeft:"10px"}} onClick={() => this.deleteDept(dept.id)} className="btn btn-danger">Delete</button>
                                                    <button style={{marginLeft:"10px"}} onClick={() => this.viewDept(dept.id)} className="btn btn-info">View</button>
                                                    <button onClick={() => this.viewComp(dept.id)} className="btn btn-danger">View Complaints</button>
                                                    </td>
                                                   
                                                    </tr>
                                               
                                           
                                           
                                )  
                                
                            }
                            
                         </tbody>
                    </table>
                    <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To Main</button>
                    
                    </div>               
                </div>
            </div>
         
            </div>
        );
    }
}

export default DeptComponent;