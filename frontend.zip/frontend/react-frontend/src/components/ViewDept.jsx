import React, { Component } from 'react';
import DepService from '../services/DepService';

class ViewDept extends Component {
    constructor(props){
        super(props)

        this.state={
            id:this.props.match.params.id,
            dept:{}
        }
         }
    componentDidMount(){
       /* let user=JSON.parse(localStorage.getItem("citizens"));
        this.setState({
            citizen:user
        })*/
     DepService.getDeptById(this.state.id).then(res=>{
            this.setState({dept:res.data});
        })

    }
  
    render() {
        return (
            <div>
              
            <div className="card col-md-6 offset-md-3">
            <h3 className="text-center">View Department Details</h3>
            <div className="card-body">
                        <div className="row">
                        
                            <label>Department Id:</label>
                            <div>{ this.state.dept.id}</div>

                        </div>
                        <div className="row">
                            <label>Department Name:</label>
                            <div>{ this.state.dept.deptName }</div>

                        </div>
                        <div className="row">
                            <label>Department Contact No:</label>
                            <div>{ this.state.dept.deptContactNo}</div>
                            </div>

            </div>
                </div>
            </div>
        );
    }
}

export default ViewDept;