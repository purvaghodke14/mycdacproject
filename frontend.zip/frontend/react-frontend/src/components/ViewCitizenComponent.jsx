import React, { Component } from 'react';
import CitizenService from '../services/CitizenService';

class ViewCitizenComponent extends Component {
    constructor(props){
        super(props)

        this.state={
            id:this.props.match.params.id,
            citizen:{}
        }
        this.editCitizen=this.editCitizen.bind(this);
        this.deleteCitizen=this.deleteCitizen.bind(this);
        this.propTax=this.propTax.bind(this);
    }

    componentDidMount(){
        let user=JSON.parse(localStorage.getItem("citizens"));
        this.setState({
            citizen:user
        })
        /*CitizenService.getCitizensById(this.state.id).then(res=>{
            this.setState({citizen:res.data});
        })*/

    }
    deleteCitizen(id){
        CitizenService.deleteCitizen(id).then(res =>{
            this.setState({citizens:this.state.citizens.filter(citizen => citizen.id !== id)});
            this.props.history.push('/');
           
            });
        
       
      
    }
    editCitizen(){
        this.props.history.push('/update-citizen/id');
    }
    giveComplaint(){
        this.props.history.push('/complaint');
    }
    logout() {
        localStorage.removeItem("citizens");
        window.location="/";
        //this.props.history.push('/');

      }
      propTax(){
          this.props.history.push('/proptax')
      }
      birthCertificate(){
          this.props.history.push('/birth');
      }
      deathCertificate(){
        this.props.history.push('/deathcer');
      }
    render() {
        return (
            <div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                 <button style={{marginRight:"100px"}} onClick={() => this.logout()} className="btn btn-danger">Logout</button>
                 </div>
            
                     <h1 className="text-center">Welcome!!!!!!</h1>
                     <h3>---------------------------------------------------------------------------------------------------------------------------------</h3>
                    <h3 className="text-center">View Citizen Details</h3>
                   
                      
                    <div class="table-responsive">          
                        <table class="table">
                        <thead>
                            <tr>
                        <td>
                            <label>Citizen First Name:</label>
                           <tr> { this.state.citizen.firstName }</tr>
                        
                          </td>
                           <td>
                            <label>Citizen Last Name:</label>
                            <tr>{ this.state.citizen.lastName }</tr>
                            </td>
                        <td>
                            <label>Citizen EmailId:</label>
                            <tr>{ this.state.citizen.emailId }</tr>

                       </td>
                       <td>
                            <label>Citizen Contact No:</label>
                           <tr>{ this.state.citizen.contactNo}</tr>

                            </td>
                        
                       
                            </tr>
                        </thead>
                        </table>
                        </div>
                        <h2>_____________________________________________________________________________________________________________________________________________</h2>
                       <h2>Accessing EServices</h2>
                        <button style={{marginRight:"10px"}} onClick={() => this.editCitizen()} className="btn btn-info">Update Details</button>
                        
                      
                        <button onClick={() => this.giveComplaint()} className="btn btn-info">Give Complaint</button>
                        <button style={{marginLeft:"10px"}}  onClick={() => this.propTax()} className="btn btn-info">Pay Property Tax</button>
                        
                        <button style={{marginLeft:"10px"}} onClick={() => this.birthCertificate()} className="btn btn-info">Apply For BirthCertificate</button>
                        <button style={{marginLeft:"10px"}} onClick={() => this.deathCertificate()} className="btn btn-info">Apply For DeathCertificate</button>
                        
                        
                    
                        
                       
                       
                        </div>
                        
                
               
          
        );
    }
}

export default ViewCitizenComponent;