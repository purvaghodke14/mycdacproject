import React, { Component } from 'react';
import CitizenService from '../services/CitizenService';

class ListCitizensComponents extends Component {

    constructor(props){
        super(props)

        this.state={
            citizens:[]
        }
        this.register=this.register.bind(this);
        this.login=this.login.bind(this);
        this.adminlogin=this.adminlogin.bind(this);
        this.editCitizen=this.editCitizen.bind(this);
        this.deleteCitizen=this.deleteCitizen.bind(this);
        this.viewCitizen=this.viewCitizen.bind(this);
        this.allDept=this.allDept.bind(this);
    }

    deleteCitizen(id){
        CitizenService.deleteCitizen(id).then(res =>{
            this.setState({citizens:this.state.citizens.filter(citizen => citizen.id !== id)});
        });
    }
    viewCitizen(id){
        this.props.history.push(`/view-citizen/${id}`);
    }
    viewAdminCitizen(id){
        this.props.history.push(`/view-admin/${id}`);
    }

    editCitizen(id){
        this.props.history.push(`/update-citizen/${id}`);

    }

    componentDidMount(){
        CitizenService.getCitizens().then((res)=>{
        this.setState({citizens:res.data});
      });
        
    }
    register(){
        this.props.history.push('/register');
    }
    login(){
        
        this.props.history.push('/login');
    }
    adminlogin()
    {
        this.props.history.push('/admin-login');
    }
    allDept(){
        this.props.history.push('/dept');
    }

    render() {
        return (
            <div>
                <div className="container">
                <h2 className="text-center">Citizen List</h2>
                <button className="btn btn-success" onClick={this.allDept}>Departments</button>
                <div className="row">
                    
                <div className="card-body">
                    <table className="table table-striped table-bordered table-dark table-responsive-lg" >
                        <thead>
                            <tr>
                                <th> Citizen ID </th>

                                <th> Citizen First Name </th>

                                <th> Citizen Last Name </th>

                                <th> Citizen ContactNo </th>
                                
                                <th> Citizen emailId </th>
                                
                                <th>Citizen Password </th>

                                <th>    Actions     </th>
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.citizens.map (
                                    citizen =>
                                            <tr key={citizen.id}>
                                                <td>{citizen.id}</td>
                                                <td>{citizen.firstName}</td>
                                                <td>{citizen.lastName}</td>
                                                <td>{citizen.contactNo}</td>
                                                <td>{citizen.emailId}</td>
                                                <td>{citizen.password}</td>
                                                <td>
                                                    <button style={{marginLeft:"10px"}} onClick={() => this.editCitizen(citizen.id)} className="btn btn-info">Update</button>
                                                    <button style={{marginLeft:"10px"}} onClick={() => this.deleteCitizen(citizen.id)} className="btn btn-danger">Delete</button>
                                                    <button style={{marginLeft:"130px"}} onClick={() => this.viewCitizen(citizen.id)} className="btn btn-info">View</button>
                                                    <button style={{marginLeft:"130px"}} onClick={() => this.viewAdminCitizen(citizen.id)} className="btn btn-info">View</button>
                                                </td>
                                            </tr>
                                )  
                                
                            }
                            
                         </tbody>
                    </table>
                    
                    </div>
                </div>
            </div>
            </div>
        );
    }
}

export default ListCitizensComponents;