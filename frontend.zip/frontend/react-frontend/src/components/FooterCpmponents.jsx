import React, { Component } from 'react';

class FooterCpmponents extends Component {
    render() {
        return (
            <nav className="navbar navbar-expand-sm bg-light">
                <footer className="container-fluid bg-4 text-center">
                <span className="text-muted">All Rights Reserved 2021 @SmartCity</span>
                </footer>
            </nav>
        );
    }
}

export default FooterCpmponents;