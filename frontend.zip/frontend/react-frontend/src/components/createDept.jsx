import React, { Component } from 'react';
import DepService from '../services/DepService';
class createDept extends Component {
    constructor(props){
        super(props)

        this.state={
            id:'',
            deptName:'',
            deptContactNo:''
            
        }
       // this.changeDeptIdHandler=this.changeDeptIdHandler.bind(this);
        this.changedeptNameHandler=this.changedeptNameHandler.bind(this);
        this.changedeptContactNoHandler=this.changedeptContactNoHandler.bind(this);
        this.saveDept=this.saveDept.bind(this);
    }

    componentDidMount(){
        DepService.getDeptById(this.state.id).then((res)=>{
            let depts=res.data;
            this.setState({ 
                id:depts.id,
                deptName:depts.deptName,
                deptContactNo:depts.deptContactNo
                
            });
            

        });
    }

    saveDept=(e)=>{
        e.preventDefault();

        let depts={id:this.state.id,deptName:this.state.deptName,deptContactNo:this.state.deptContactNo};
        console.log('depts =>'+ JSON.stringify(depts));

        

        
            DepService.createDept(depts).then(res=>{
                this.props.history.push('/dept');
            });
        
        

            
    }
   

    changedeptNameHandler= (event)=>{
        this.setState({deptName:event.target.value});
    }
    changedeptContactNoHandler= (event)=>{
        this.setState({deptContactNo:event.target.value});
    }
    cancel(){
        this.props.history.push('/citizens');

    }


    render() {
        return (
            <div>
            <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h3 className="text-center">Add New Department</h3>
                        
                        <div className="card-body">
                        <form>
                        
                      

                            <div className="form-group">
                                <label>Department Name:</label>
                                <input placeholder="Department Name" name="deptName" className="form-control" value={this.state.deptName} onChange={this.changedeptNameHandler}/>
                            </div>

                            
                            <div className="form-group">
                                <label>Contact No:</label>
                                <input placeholder="Contact No" name="deptContactNo" className="form-control" value={this.state.deptContactNo} onChange={this.changedeptContactNoHandler}/>
                            </div>
                            
                            <button className="btn btn-success" onClick={this.saveDept}>Add</button>
                            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}> Cancel</button>
                        </form>
                        </div>
                    </div>

                </div>
            </div>
            </div>
        );
    }
}




export default createDept;