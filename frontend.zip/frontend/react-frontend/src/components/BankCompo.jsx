import React, { Component } from 'react';
import Input from "react-validation/build/input";
import  Form from 'react-validation/build/form';
import BankService from '../services/BankService';
const required = value => {
    if (!value) {
      return (
        <div className="alert alert-danger" role="alert">
          This field is required!
        </div>
      );
    }
  };
class BankCompo extends Component {
    constructor(props){
        super(props)

        this.state={
            name:'',
            bankName:'',
            branchName:'',
            cardNumber:'',
            paymentAmount:'',
            expiryDate:'',
            cvvNumber:'',
           
        }
        this.changeNameHandler=this.changeNameHandler.bind(this);
       this.changeBankNameHandler=this.changeBankNameHandler.bind(this);
       this.changeBranchNameHandler=this.changeBranchNameHandler.bind(this);
       this.changecardNumberHandler=this.changecardNumberHandler.bind(this);
       this.changePaymentAmountHandler=this.changePaymentAmountHandler.bind(this);
       this.changeCVVNumHandler=this.changeCVVNumHandler.bind(this);
       this.changeExpHandler=this.changeExpHandler.bind(this);
        this.cancel=this.cancel.bind(this);
    }
    componentDidMount(){

    
        BankService.getPaymentById(this.state.id).then((res) =>{
            let bank=res.data;
            this.setState({ 
                id:bank.id,
                name:bank.name,
                bankName:bank.bankName,
                branchName:bank.branchName,
                cardNumber:bank.cardNumber,
                paymentAmount:bank.paymentAmount,
                expiryDate:bank.expiryDate,
                cvvNumber:bank.cvvNumber
                
                
            });

        });
    }
    saveDetails=(e) => {
        e.preventDefault();

        let bank={id:this.state.id,name:this.state.name,bankName:this.state.bankName,branchName:this.state.branchName,cardNumber:this.state.cardNumber,paymentAmount:this.state.paymentAmount,expiryDate:this.state.expiryDate,cvvNumber:this.state.cvvNumber};
        console.log('bank =>'+ JSON.stringify(bank));

        

        
            BankService.createPayment(bank).then(res=>{
               window.location="/view-bank";
            });
        
        

    }
    changeNameHandler=(event)=>{
        this.setState({name:event.target.value});
    }
    changeBankNameHandler= (event)=>{
        this.setState({bankName:event.target.value});
    }
    changeBranchNameHandler=(event)=>{
        this.setState({branchName:event.target.value});
    }
    changePaymentAmountHandler=(event)=>{
        this.setState({paymentAmount:event.target.value});
    }
    changeCVVNumHandler=(event)=>{
        this.setState({cvvNumber:event.target.value});
    }
    changecardNumberHandler=(event)=>{
        this.setState({cardNumber:event.target.value});
    }
    changeExpHandler=(event)=>{
        this.setState({expiryDate:event.target.value});
    }
    cancel(){
        this.props.history.push('/cancelPayment');
 
     }
    render() {
        return (
            <div>
                <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h3 className="text-center">Fill BankDeatils</h3>
                        
                        <div className="card-body">
                        <Form>
                        <div className="form-group">
                                <label>Citizen Name:</label>
                                <Input placeholder="Citizen Name" name="name" className="form-control" value={this.state.name} validations={[required]} onChange={this.changeNameHandler}/>
                            </div>
                        <div className="form-group">
                                <label>Bank Name:</label>
                                <Input placeholder="Bank Name" name="bankName" className="form-control" value={this.state.bankName} validations={[required]} onChange={this.changeBankNameHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Branch Name:</label>
                                <Input placeholder="Branch Name" name="branchName" className="form-control" value={this.state.branchName}  validations={[required]} onChange={this.changeBranchNameHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Card Number:</label>
                                <Input placeholder="Card Number" name="cardNumber" className="form-control" value={this.state.cardNumber}  validations={[required]} onChange={this.changecardNumberHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Payment Amount:</label>
                                <Input placeholder="Payment Amount" name="paymentAmount" className="form-control" value={this.state.paymentAmount}  validations={[required]} onChange={this.changePaymentAmountHandler}/>
                            </div>
                            
                            
                            <div className="form-group">
                                <label> Expiry Date of Card:</label>
                                <Input type="date" placeholder="DateOfBirth" name="expiryDate" className="form-control" value={this.state.expiryDate} validations={[required]} onChange={this.changeExpHandler}/>
                            </div>

                            <div className="form-group">
                                <label>CVV Number:</label>
                                <Input placeholder="CVV Number" name="cvvNumber" className="form-control" value={this.state.cvvNumber} onChange={this.changeCVVNumHandler}/>
                            </div>
                            
                            <button className="btn btn-success" onClick={this.saveDetails}>Submit</button>
                            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}> Cancel</button>
                        </Form>
                        </div>
                    </div>

                </div>
            </div>
            </div>
        );
    }
}

export default BankCompo;