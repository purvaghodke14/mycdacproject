
import React, { Component } from 'react';
import Input from "react-validation/build/input";
import  Form from 'react-validation/build/form';
import BirthService from '../services/BirthService';
import DeathService from '../services/DeathService';

const required = value => {
    if (!value) {
      return (
        <div className="alert alert-danger" role="alert">
          This field is required!
        </div>
      );
    }
  };
class DeathCerCom extends Component {
    constructor(props){
        super(props)

        this.state={
            name:'',
            f_name:'',
            gender:'',
            dateOfDeath:'',
            death_location:'',
            address:'',
            age:'',
            nationality:'',
            religion:''
        }
        this.changeDNameHandler=this.changeDNameHandler.bind(this);
        this.changeFNameHandler=this.changeFNameHandler.bind(this);
        this.changeAgeHandler=this.changeAgeHandler.bind(this);
        this.changeDODHandler=this.changeDODHandler.bind(this);
        this.changeLocationHandler=this.changeLocationHandler.bind(this);
        this.changeAddressHandler=this.changeAddressHandler.bind(this);
        this.changeNationalityHandler=this.changeNationalityHandler.bind(this);
        this.changeReligionHandler=this.changeReligionHandler.bind(this);
        this.cancel=this.cancel.bind(this);
    }
    componentDidMount(){

    
        DeathService.getDeathById(this.state.id).then((res) =>{
            let death=res.data;
            this.setState({ 
                id:death.id,
                name:death.name,
                f_name:death.f_name,
                gender:death.gender,
                dateOfDeath:death.dateOfDeath,
                death_location:death.death_location,
                address:death.address,
                age:death.age,
                nationality:death.nationality,
                religion:death.religion
                
            });

        });
    }
    saveCertificate=(e) => {
        e.preventDefault();

        let death={id:this.state.id,name:this.state.name,f_name:this.state.f_name,gender:this.state.gender,dateOfDeath:this.state.dateOfDeath,death_location:this.state.death_location,address:this.state.address,age:this.state.age,nationality:this.state.nationality,religion:this.state.religion};
        console.log('death =>'+ JSON.stringify(death));

        

        
            DeathService.createCertificate(death).then(res=>{
               window.location="/cerSucc";
            });
        
        

    }
    changeFNameHandler= (event)=>{
        this.setState({f_name:event.target.value});
    }
    changeAddressHandler=(event)=>{
        this.setState({address:event.target.value});
    }
    changeDNameHandler=(event)=>{
        this.setState({name:event.target.value});
    }
    changeAgeHandler=(event)=>{
        this.setState({age:event.target.value});
    }
    changeDODHandler=(event)=>{
        this.setState({dateOfDeath:event.target.value});
    }
    changeLocationHandler=(event)=>{
        this.setState({death_location:event.target.value});
    }
    changeNationalityHandler=(event)=>{
        this.setState({nationality:event.target.value});
    }
    changeReligionHandler=(event)=>{
        this.setState({religion:event.target.value});
    }
    setGender=(event) =>{
        this.setState({gender:event.target.value});
      }
      cancel(){
        this.props.history.push('/view-citizen');

    }



    render() {
        return (
            <div>
                 <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h3 className="text-center">Application form of DeathCertificate</h3>
                        
                        <div className="card-body">
                        <Form>
                        
                        <div className="form-group">
                                <label>Deceased name:</label>
                                <Input placeholder="Deceased name" name="name" className="form-control" value={this.state.name} validations={[required]} onChange={this.changeDNameHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Father/Husband Name:</label>
                                <Input placeholder="Father Name" name="f_name" className="form-control" value={this.state.f_name} onChange={this.changeFNameHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Age:</label>
                                <Input type="number" placeholder="Age" name="mName" className="form-control" value={this.state.age} onChange={this.changeAgeHandler}/>
                            </div>
                            
                            
                            <div  class="form-check form-check-inline"  onChange={this.setGender.bind(this)}>
                            <label>Gender:</label>
                                    <Input type="radio" value="MALE" name="gender"/> Male <Input type="radio" value="FEMALE" name="gender"/> Female
                             </div>
                            
                            <div className="form-group">
                                <label>DateOfDeath:</label>
                                <Input type="date" placeholder="DateOfDeath" name="dateOfDeath" className="form-control" value={this.state.dateOfDeath} onChange={this.changeDODHandler}/>
                            </div>

                            <div className="form-group">
                                <label>Death location:</label>
                                <Input placeholder="Death location" name="death_location" className="form-control" value={this.state.deathLocation} onChange={this.changeLocationHandler}/>
                            </div>
                            <div className="form-group">
                                <label>Address:</label>
                                <Input placeholder="Address" name="address" className="form-control" value={this.state.address} onChange={this.changeAddressHandler}/>
                            </div>
                            <div className="form-group">
                                <label> Nationality:</label>
                                <Input placeholder="Nationality" name="nationality" className="form-control" value={this.state.nationality} onChange={this.changeNationalityHandler}/>
                            </div>
                            <div className="form-group">
                                <label> Religion:</label>
                                <Input placeholder="Religion" name="religion" className="form-control" value={this.state.religion} onChange={this.changeReligionHandler}/>
                            </div>
                            
                            <button className="btn btn-success" onClick={this.saveCertificate}>Submit</button>
                            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}> Cancel</button>
                        </Form>
                        </div>
                    </div>

                </div>
            </div>
            </div>
        );
    }
}

export default DeathCerCom;