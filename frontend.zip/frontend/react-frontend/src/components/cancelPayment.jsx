import React, { Component } from 'react';

class cancelPayment extends Component {
    backDept()
    {
       window.location='/view-citizen';
    }
    render() {
        return (
            <div>
                You are cancelling your Payment......
                <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To main page</button>
            </div>
        );
    }
}


export default cancelPayment;