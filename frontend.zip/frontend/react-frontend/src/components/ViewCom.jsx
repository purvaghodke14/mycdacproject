import React, { Component } from 'react';
import CompService from '../services/CompService';

class ViewCom extends Component {
    constructor(props){
        super(props)

        this.state={
           id:this.props.match.params.id,
           complaints:[]
        }
         }
         componentDidMount(){
             //console.log(this.state.id)
          
          CompService.retriveAllComplaints(this.state.id).then(res=>{
            const data=JSON.stringify(res);
            //console.log(data.data.result);
            const data1=JSON.parse(data);
            console.log(data1.data);
            
            this.setState({
                complaints:data1.data
                
            })
             });
             //console.log(this.state.complaints)
     
         }
         
    render() {
        return (
            <div>
                  <div className="card col-md-6 offset-md-3">
            <h3 className="text-center">View Complaints Details</h3>
            <div className="card-body">
                    
                        <div className="row">
                            <label>Department Name:</label>
                            <div>{ this.state.complaints.deptName }</div>

                        </div>
                        <div className="row">
                            <label>Complaint</label>
                            <div>{ this.state.complaints.complaint}</div>
                            </div>
                      

            </div>
                      
                </div>
            </div>
        );
    }
}

export default ViewCom;