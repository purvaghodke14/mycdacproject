import React, { Component } from 'react';
import BirthService from '../services/BirthService';

class ViewBirthCer extends Component {
    constructor(props){
        super(props)

        this.state={
            births:[]
        }
        
        //this.allDept=this.allDept.bind(this);
    }
    componentDidMount(){
        BirthService.getBirth().then((res)=>{
        this.setState({births:res.data});
      });
        
    }
    backDept()
    {
        this.props.history.push('/view-admin');
    }
    render() {
        return (
            <div>
                <div className="container">
                <h2 className="text-center">BirthCertificate Application List</h2>
                
                <div className="row">
                    
                <div className="card-body">
                    <table className="table table-striped table-bordered table-dark table-responsive-xl" >
                        <thead>
                            <tr>
                                <th> Certificate ID </th>

                                <th> Beneficiary Name </th>

                                <th> Beneficiary Father Name </th>

                                <th> Beneficiary Mother Name </th>
                                
                                <th> Beneficiary date of birth </th>
                                
                                <th>Beneficiary birth location </th>
                                <th>Beneficiary Address </th>

                             
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.births.map (
                                    birth =>
                                            <tr key={birth.id}>
                                                <td>{birth.id}</td>
                                                <td>{birth.name}</td>
                                                <td>{birth.f_name}</td>
                                                <td>{birth.mName}</td>
                                                <td>{birth.dateOfBirth}</td>
                                                <td>{birth.birth_location}</td>
                                                
                                                <td>{birth.address}</td>
                                                <td>
                                                  
                                                   
                                                </td>
                                            </tr>
                                )  
                                
                            }
                            
                         </tbody>
                    </table>
                    <button class="btn btn-primary backBtn btn-lg pull-right" type="button" onClick={() => this.backDept()}>Back To Main</button>
                    </div>
                </div>
            </div>
            </div>
        );
    }
}

export default ViewBirthCer;