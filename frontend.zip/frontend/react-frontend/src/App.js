import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
import ListCitizensComponents from './components/ListCitizensComponents';
import FooterCpmponents from './components/FooterCpmponents';
import HeaderComponents from './components/HeaderComponents';
import CreateCitizenComponent from './components/CreateCitizenComponent';
import UpdateCitizenComponents from './components/UpdateCitizenComponents';
import ViewCitizenComponent from './components/ViewCitizenComponent';
import AdminComponent from './components/AdminComponents'
import LoginComponent from './components/LoginComponent';
import CreateCitizenComponenta from './components/CreateCitizenComponenta';
import DeptComponent from './components/DeptComponent';
import createDept from './components/createDept';
import Home from './Home';
import ViewDept from './components/ViewDept';
import AdminCitizenList from './components/AdminCitizenList';
import UpdateDept from './components/UpdateDept';
import Header from './Header';
import Footer from './Footer';
import ComplaintsComp from './components/ComplaintsComp';
import ViewCom from './components/ViewCom';
import ListComp from './components/ListComp';
import PropertyTaxComp from './components/PropertyTaxComp';
import ViewPropTax from './components/ViewPropTax';
import CreateBirthApp from './components/CreateBirthApp';
import ViewBirthCer from './components/ViewBirthCer';
import SuccReg from './components/SuccReg';
import AboutUs from './components/AboutUs';
import DeathCerCom from './components/DeathCerCom';
import ViewDeathCer from './components/ViewDeathCer';
import BankCompo from './components/BankCompo';
import ViewPayment from './components/ViewPayment';
import ConformPage from './components/ConformPage';
import cancelPayment from './components/cancelPayment';
import EServices from './components/EServices';
import CertificateSucc from './components/CertificateSucc';
function App() {
  return (
    <div>
      <Router>
       
                
                    <div >
                    
                      <Switch> 
                      
                        <Route path="/" exact component={Home}></Route>
                        <Route path="/citizens" component={ListCitizensComponents}></Route>   
                        <Route path="/register" component={CreateCitizenComponenta}></Route>               
                        <Route path="/update-citizen/:id" component={UpdateCitizenComponents}></Route>
                        <Route path="/view-citizen" component={ViewCitizenComponent}></Route>
                        <Route path="/login" component={LoginComponent}></Route>
                        <Route path="/admin-login" component={AdminComponent}></Route>
                        <Route path="/dept" component={DeptComponent}></Route>
                        <Route path="/add" component={createDept}></Route>
                        <Route path="/view/:id" component={ViewDept}></Route>
                        <Route path="/view-admin" component={AdminCitizenList}></Route>
                        <Route path="/update-dept/:id" component={UpdateDept}></Route>
                        <Route path="/complaint" component={ComplaintsComp}></Route>
                        <Route path="/getcomplaint/:id" component={ListComp}></Route>
                        <Route path="/proptax" component={PropertyTaxComp}></Route>
                        <Route path="/gettax" component={ViewPropTax}></Route>
                        <Route path="/birth" component={CreateBirthApp}></Route>
                        <Route path="/birthcer" component={ViewBirthCer}></Route>
                        <Route path="/successreg" component={SuccReg}></Route>
                        <Route path="/deathcer" component={DeathCerCom}></Route>
                        <Route path="/deathcert" component={ViewDeathCer}></Route>
                        <Route path="/payment" component={BankCompo}></Route>
                        <Route path="/getpayment" component={ViewPayment}></Route>
                        <Route path="/view-bank" component={ConformPage}></Route>
                        <Route path="/cancelPayment" component={cancelPayment}></Route>
                        <Route path="/cerSucc" component={CertificateSucc}></Route>
                        <Route path="/aboutus" component={AboutUs}></Route>

                        
                       
                        
                        
                        </Switch>
                      
    
                        </div>
              
      </Router>
    </div>
  );
}

export default App;
