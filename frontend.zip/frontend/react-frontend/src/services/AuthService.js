import axios from "axios";

const API_URL = "http://localhost:8080/api/v1/citizens";

class AuthService {
  loginUser(emailId, password) {
    const fd=new FormData();
    fd.append('emailId',emailId);
    fd.append('password',password);
    
    return axios.post("http://localhost:8080/api/v1/login",fd)
      .then(response => {
       
            if (response) {
                localStorage.setItem("citizens", JSON.stringify(response.data));
            }
        return response;
      });
  }

  logout() {
    localStorage.removeItem("citizens");
  }

  createCitizen(id,firstName,lastName,emailId,password,contactNo) {
    
    const fd=new FormData();
    fd.append('id',id)
    fd.append('firstName',firstName);
    fd.append('lastName',lastName);
    fd.append('email',emailId);
    fd.append('password',password);
    fd.append('contactNo',contactNo);
    
    
    return axios.post("http://localhost:8080/api/v1/register",fd)
      .then(response => {
       
          
        return response;
      });
  }

  adminUser(emailId, password) {
    const fd=new FormData();
    fd.append('emailId',emailId);
    fd.append('password',password);
    
    return axios.post("http://localhost:8080/api/v1/adminlogin",fd)
      .then(response => {
       
            if (response) {
                localStorage.setItem("citizens", JSON.stringify(response.data));
            }
        return response;
      });
  }

  getCurrentCitizen() {
    return JSON.parse(localStorage.getItem('citizens'));;
  }
}

export default new AuthService();
