import axios from 'axios';
const CITIZEN_API_BASE_URL="http://localhost:8080/api/v1/citizens";
class CitizenService{
    getCitizens(){
        return axios.get(CITIZEN_API_BASE_URL);
    }

    createCitizen(citizens)
    {
        return axios.post(CITIZEN_API_BASE_URL,citizens);
    }

    getCitizensById(citizenId){
        return axios.get(CITIZEN_API_BASE_URL+ '/'+ citizenId);
    }

    updateCitizen(citizens,citizenId){
        return axios.put(CITIZEN_API_BASE_URL+'/'+citizenId,citizens);
    }

    deleteCitizen(citizenId){
        return axios.delete(CITIZEN_API_BASE_URL+'/'+citizenId);
    }
    loginUser(emailId,password)
    {
        return axios.post(CITIZEN_API_BASE_URL+'/'+emailId,password)
    }
   

}

    
export default new CitizenService()