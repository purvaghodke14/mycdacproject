import axios from 'axios';

const COMP_API_BASE_URL="http://localhost:8080/api/v1/proptax"

class PropTax{

getTax(location,type,value){
    const fd=new FormData();
    fd.append('location',location);
    fd.append('type',type);
    fd.append('value',value);

    return axios.post(COMP_API_BASE_URL,fd);
}
getAllTax()
{
    return axios.get("http://localhost:8080/api/v1/gettax")
}
getPropertyTaxById(id){
    return axios.get(COMP_API_BASE_URL+'/'+id);
}
}
export default new PropTax();