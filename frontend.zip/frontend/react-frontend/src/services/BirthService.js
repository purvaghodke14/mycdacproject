
import axios from 'axios';
const BIRTH_API_URL = "http://localhost:8080/api/v1/birth";
class BirthService  {
    

    getBirth(){
        return axios.get("http://localhost:8080/api/v1/birthcer");
    }

    createCertificate(certificate)
    {
        return axios.post(BIRTH_API_URL,certificate);
    }
    getBirthById(birthId){
        return axios.get(BIRTH_API_URL+ '/'+ birthId);
   
    }
}


export default new BirthService();