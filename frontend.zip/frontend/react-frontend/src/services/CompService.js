import axios from 'axios';
const COMP_API_BASE_URL="http://localhost:8080/api/v1/complaint";

class CompService {
  
    getComplaint()
    {
        return axios.get(COMP_API_BASE_URL);
    }
    createComplaint(id,deptName,complaint)
    {
         const fd=new FormData();
        fd.append('id',id);
        fd.append('deptName',deptName);
        fd.append('complaint',complaint);
        return axios.post(COMP_API_BASE_URL,fd);

    }
    
    retriveAllComplaints(id){
        return axios.get("http://localhost:8080/api/v1/getcomplaint",{params:{id}}).then(response => {
       
            
                     return response;
                   });
            
         };
    
   
    
}

export default new  CompService();