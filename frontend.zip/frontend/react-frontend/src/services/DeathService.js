import axios from 'axios';
const DEATH_API_URL = "http://localhost:8080/api/v1/deathcer";
class DeathService  {
    

    getDeath(){
        return axios.get("http://localhost:8080/api/v1/deathcert");
    }

    createCertificate(certificate)
    {
        return axios.post(DEATH_API_URL,certificate);
    }
    getDeathById(deathId){
        return axios.get(DEATH_API_URL+ '/'+ deathId);
   
    }
}


export default new DeathService();