import axios from 'axios';
const BANK_API_URL = "http://localhost:8080/api/v1/payment";
class BankService  {
    

    getAllPayment(){
        return axios.get("http://localhost:8080/api/v1/getpayment");
    }

    createPayment(bank)
    {
        return axios.post(BANK_API_URL,bank);
    }
    getPaymentById(bankID){
        return axios.get(BANK_API_URL+ '/'+bankID);
   
    }
}


export default new BankService();