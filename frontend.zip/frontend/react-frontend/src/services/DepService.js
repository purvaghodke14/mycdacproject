import axios from 'axios';

const DEPT_API_BASE_URL="http://localhost:8080/api/v1/dept";

class DeptService{
    getDept(){
        return axios.get(DEPT_API_BASE_URL);
    }
    createDept(depts)
    {
        return axios.post(DEPT_API_BASE_URL,depts);
    }
    getDeptById(id)
    {
        return axios.get(DEPT_API_BASE_URL+'/'+id);
    }
    updateDept(depts,id){
        return axios.put(DEPT_API_BASE_URL+'/'+id,depts);


    }
    deleteDept(id)
    {
        return axios.delete(DEPT_API_BASE_URL+'/'+id);
    }
    

}
export default new DeptService()