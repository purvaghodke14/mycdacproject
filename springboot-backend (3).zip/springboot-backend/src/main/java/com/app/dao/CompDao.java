package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojo.Complaints;
import com.app.pojo.Dept;

public interface CompDao extends JpaRepository<Complaints, Long>{

	 @Query ("select c from Complaints c where c.deptName= :deptName")
	 	Complaints  findByDeptName(String deptName);

//	 	@Query("select c form Complaints where c.dept_id=:dept_id")
//	 	Complaints findByDeptId(long did);

	

}

