package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.app.pojo.Admin;

@Repository
public interface AdminDao extends JpaRepository<Admin,Long>{
	@Query("select a from Admin a where a.emailId= :emailId and a.password= :password ")
	Admin authenticateAdmin(String emailId,String password);

}
