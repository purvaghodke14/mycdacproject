package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.pojo.Dept;

@Repository
public interface DeptDao extends JpaRepository<Dept, Long>{

	Dept findByDeptName(String deptName);

	Dept findById(Dept did);


	

}
