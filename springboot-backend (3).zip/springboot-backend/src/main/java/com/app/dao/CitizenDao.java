package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.app.pojo.Citizen;


@Repository
public interface CitizenDao extends JpaRepository<Citizen, Long>{
	Optional<Citizen> findByEmailIdAndPassword(String emailId,String password);
	@Query("select c from Citizen c where c.emailId= :emailId and c.password= :password ")
	Citizen authenticateCitizen(String emailId,String password);
	
}
