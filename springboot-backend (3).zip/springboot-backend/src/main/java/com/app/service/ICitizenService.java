package com.app.service;

import com.app.pojo.Citizen;

public interface ICitizenService {
 Citizen authenticateCitizen(String emailId,String password);
	
	
}
