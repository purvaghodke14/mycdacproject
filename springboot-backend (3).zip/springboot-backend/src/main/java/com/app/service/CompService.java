//package com.app.service;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.app.dao.CompDao;
//import com.app.dao.DeptDao;
//import com.app.pojo.Complaints;
//import com.app.pojo.Dept;
//
//@Transactional
//@Service
//public class CompService {
//	
//	@Autowired
//	private CompDao dao;
//	
//	@Autowired
//	private DeptDao deptDao;
//	
//	public Complaints getCompByDeptId( long did) {
//		Optional<Dept> dept=deptDao.findById(did);
//		
//		dao.findByDept(dept);
//	}
//
//}
