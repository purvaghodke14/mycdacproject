package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CitizenDao;
import com.app.pojo.Citizen;


@Service
@Transactional
public class CitizenServiceImpl implements ICitizenService {
	@Autowired
	private CitizenDao citizenRepository;

	@Override
	public Citizen authenticateCitizen(String emailId, String password) {
	
		return citizenRepository.authenticateCitizen(emailId, password);
	}

	
}
