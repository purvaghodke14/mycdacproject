package com.app.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.CitizenDao;
import com.app.dao.CompDao;
import com.app.dao.DeptDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.Complaints;
import com.app.pojo.Dept;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")

public class CompController{

	@Autowired
	CitizenDao citizenRepository;
	@Autowired
	CompDao compRepository;
	
	@Autowired 
	DeptDao deptRepository;
	
	/*@GetMapping("/complaint")
	public List<Complaints> findAll() {
			return compRepository.findAll();
	}*/
	
	//create compliant rest api
	@PostMapping("/complaint")
	public Complaints createComplaint(@RequestParam long id,@RequestParam String deptName ,@RequestParam String complaint) {
		//Citizen citizen=citizenRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Citizen not exist with id:"+id));
		Dept did=deptRepository.findByDeptName(deptName);
		//long dept= deptRepository.findById(did).orElseThrow(() ->new ResourceNotFoundException("Dept not exist with id:"+did));
		Complaints complaints=new Complaints(did,complaint,deptName,LocalDate.now());
		return  compRepository.save(complaints);
	}
	
	//get complaints by id rest 
//	@GetMapping("/getcomplaint/{did}")
//	public ResponseEntity<Complaints> getComplaintByDeptId(@PathVariable long id) {
//		Complaints  dept= compRepository.findByDeptId(id);
//		return ResponseEntity.ok (dept);
//	}
	
	
//	@GetMapping("/getcomplaint/{id}")
//	public ResponseEntity<Optional<Dept>> retriveAllComplaints(@PathVariable Long id) 
//	{
//		Optional<Dept> deptOptional= deptRepository.findById(id);  
//		
//			return ResponseEntity.ok(deptOptional);
//		
//		
//	}
	@GetMapping("/getcomplaint")
	public List<Complaints> retriveAllComplaints(@RequestParam Long id)  
	{  
	Optional<Dept> deptOptional= deptRepository.findById(id);  
	return deptOptional.get().getComplaints();
	}  

	
	

	
}
