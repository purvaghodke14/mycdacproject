package com.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.DeptDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.Citizen;
import com.app.pojo.Dept;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class DeptController {
	@Autowired
	DeptDao deptRepository;
	
	//get all dept details
		@GetMapping("/dept")
		public List<Dept> getAllDept(){
			return deptRepository.findAll();
		}
		//create dept rest api
		@PostMapping("/dept")
		public Dept createDept(@RequestBody Dept dept) {
			return deptRepository.save(dept);
		}
		//get dept by id rest api
		@GetMapping("/dept/{id}")
		public ResponseEntity<Dept>  getDeptById(@PathVariable Long id) {
			Dept dept=deptRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Dept not exist with id:"+id));
			return ResponseEntity.ok(dept);
		}
		//update Dept rest api
		@PutMapping("/dept/{id}")
		public ResponseEntity<Dept> updateDept(@PathVariable Long id,@RequestBody Dept deptDetails)
		{
			Dept dept=deptRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Citizen not exist with id:"+id));
			
			
			dept.setDeptContactNo(deptDetails.getDeptContactNo());
			dept.setDeptName(deptDetails.getDeptName());
			
			Dept updatedDept=deptRepository.save(dept);
			return ResponseEntity.ok(updatedDept);
		}
		
		
		//delete dept rest api
		@DeleteMapping("/dept/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteDept(@PathVariable Long id){
			Dept dept=deptRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Citizen not exist with id:"+id));
			
			deptRepository.delete(dept);
			Map<String, Boolean> response=new HashMap<>();
			response.put("Deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}

		

	

	
}
