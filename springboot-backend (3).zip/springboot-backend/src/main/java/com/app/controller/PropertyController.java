package com.app.controller;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.PropertyDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.PropertyTax;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")

public class PropertyController  {

	@Autowired
	private PropertyDao propertyRepository;
	
	@GetMapping("/gettax")
	public List<PropertyTax> getAllPropertyTax(){
		return propertyRepository.findAll();
	}

	@PostMapping("/proptax")
	public PropertyTax getTax(@RequestParam String location,@RequestParam String type,@RequestParam double value)
	{
			double tax = 0.92, rate = 1.05;
			value=value*tax;
			 value=(value/100)*rate;
	
			PropertyTax propertyTax=new PropertyTax(location, type, value);
			PropertyTax p= propertyRepository.save(propertyTax);
			System.out.println("__________________"+p);
			return p;
			
	}

	@GetMapping("/proptax/{id}")
	public ResponseEntity<PropertyTax>  getPropertyTaxById(@PathVariable Long id) {
		PropertyTax props=propertyRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Citizen not exist with id:"+id));
		return ResponseEntity.ok(props);
	}
	

}
