package com.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.CitizenDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.Citizen;



@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")

public class CitizenController {

	@Autowired
	private CitizenDao citizenRepository;
	
	
	
	//get all citizen details
	@GetMapping("/citizens")
	public List<Citizen> getAllCitizens(){
		return citizenRepository.findAll();
	}
	
	//create citizen rest api
	@PostMapping("/citizens")
	public Citizen createCitizen(@RequestBody Citizen citizen) {
		return citizenRepository.save(citizen);
	}
	//get citizen by id rest api
	@GetMapping("/citizens/{id}")
	public ResponseEntity<Citizen>  getCitizenById(@PathVariable Long id) {
		Citizen citizen=citizenRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Citizen not exist with id:"+id));
		return ResponseEntity.ok(citizen);
	}
	
	//update citizen rest api
	@PutMapping("/citizens/{id}")
	public ResponseEntity<Citizen> updateCitizen(@PathVariable Long id,@RequestBody Citizen citizenDetails)
	{
		Citizen citizen=citizenRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Citizen not exist with id:"+id));
		
		
		citizen.setFirstName(citizenDetails.getFirstName());
		citizen.setLastName(citizenDetails.getLastName());
		citizen.setEmailId(citizenDetails.getEmailId());
		citizen.setContactNo(citizenDetails.getContactNo());
		
		Citizen updatedCitizen=citizenRepository.save(citizen);
		return ResponseEntity.ok(updatedCitizen);
	}
	
	
	//delete citizen rest api
	@DeleteMapping("/citizens/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteCitizen(@PathVariable Long id){
		Citizen citizen=citizenRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Citizen not exist with id:"+id));
		
		citizenRepository.delete(citizen);
		Map<String, Boolean> response=new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@PostMapping("/login")
	public Citizen loginUser(@RequestParam String emailId,@RequestParam String password)
	{
	

	Citizen authenticateCitizen=citizenRepository.authenticateCitizen(emailId, password);
	
	if(authenticateCitizen==null)
	throw new  ResourceNotFoundException("user not found");

	return authenticateCitizen;

	}
	
	
	
	

	
	}
	

