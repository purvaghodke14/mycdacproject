package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.BankDao;
import com.app.dao.CitizenDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.Bank;
import com.app.pojo.Citizen;


@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class BankController {
	
	@Autowired
	private BankDao bankRepository;
	@Autowired
	CitizenDao citizenRepository;
	
	@GetMapping("/getpayment")
	public List<Bank> getAllPayment(){
		return bankRepository.findAll();
	}
	@PostMapping("/payment")
	public Bank createPayment(@RequestBody Bank bank) {
		return bankRepository.save(bank);
	}
	@GetMapping("/payment/{id}")
	public ResponseEntity<Bank>  getPaymentById(@PathVariable Long id) {
		Bank bank=bankRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("bankdetails not exist with id:"+id));
		return ResponseEntity.ok(bank);
	}


}
