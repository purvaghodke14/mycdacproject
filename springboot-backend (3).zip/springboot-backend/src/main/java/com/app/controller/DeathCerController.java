package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.DeathCerDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.BirthCertificate;
import com.app.pojo.DeathCertificate;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class DeathCerController {
	
	@Autowired
	DeathCerDao deathRepository;
	
	
	//get all death details
	  
	  @GetMapping("/deathcert") 
	  public List<DeathCertificate> getAllDeath(){ 
		  return  deathRepository.findAll(); 
		  }
	  
	  //create death rest api
	  
	  @PostMapping("/deathcer") 
	  public DeathCertificate createCertificate(@RequestBody DeathCertificate certificate) 
	  { 
		  return deathRepository.save(certificate);
		  }
	  
	  
	  @GetMapping("/deathcer/{id}")
		public ResponseEntity<DeathCertificate>  getDeathById(@PathVariable Long id) {
		  DeathCertificate death=deathRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("DeathCertificate not exist with id:"+id));
			return ResponseEntity.ok(death);
		}

}
