
  package com.app.controller;
  
  import java.util.List;
  
  import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping; 
  import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.BirthDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.BirthCertificate;
import com.app.pojo.Citizen;
  
@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
  
  public class BirthController {
  
  @Autowired 
  private BirthDao birthRepository;
  
  //get all birthdetails
  
  @GetMapping("/birthcer") 
  public List<BirthCertificate> getAllBirth(){ 
	  return  birthRepository.findAll(); 
	  }
  
  //create citizen rest api
  
  @PostMapping("/birth") 
  public BirthCertificate createCertificate(@RequestBody BirthCertificate certificate) 
  { 
	  return birthRepository.save(certificate);
	  }
  
  @GetMapping("/birth/{id}")
	public ResponseEntity<BirthCertificate>  getBirthById(@PathVariable Long id) {
	  BirthCertificate birth=birthRepository.findById(id).orElseThrow(()  ->new ResourceNotFoundException("Birthcertificate not exist with id:"+id));
		return ResponseEntity.ok(birth);
	}
  
  }
 