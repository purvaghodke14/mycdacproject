package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.AdminDao;
import com.app.dao.CitizenDao;
import com.app.exception.ResourceNotFoundException;
import com.app.pojo.Admin;
import com.app.pojo.Citizen;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class AdminController {
	@Autowired
	private AdminDao adminRepository;
	
	
	

	@PostMapping("/adminlogin")
		public Admin adminUser(@RequestParam String emailId,@RequestParam String password)
		{


			Admin authenticateAdmin=adminRepository.authenticateAdmin(emailId, password);

					if(authenticateAdmin==null)
					throw new  ResourceNotFoundException("user not found");

					return authenticateAdmin;
		}


}
