
  package com.app.pojo;
  
  import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
  
  @Entity
  
  @Table(name="birth_certificate") 
  
  public class BirthCertificate {
	  
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  	private long id;
  
  @Column(name="beneficiary_name")
  @NotBlank 
  private String name;
  
  @Column(name="father_name")
  private String f_name;
  
  @Column(name="mother_name")
  private String mName;
  
  @Column(name="gender")
  @NotBlank 
  private String gender;
  
  @Column(name="date_of_birth")
   @NotNull 
   private LocalDate dateOfBirth;
  
  @Column(name="birth_location")
  @NotBlank private 
  String birth_location;
  
  @Column(name="permanent_addr")
  @NotBlank 
  private String address;
  
  public BirthCertificate() {
	  super();
  }
  
  public BirthCertificate( String name, String f_name, String mName, String gender, LocalDate dateOfBirth, String birth_location, String address)
  {
  super(); 
  this.name = name;
  this.f_name = f_name; 
  this.mName = mName;
  this.gender = gender; 
  this.dateOfBirth = dateOfBirth; 
  this.birth_location =birth_location; 
  this.address = address; 
  }
  
  public String getName() { return name; }
  
  public void setName(String name) { this.name = name; }
  
  public String getF_name() { return f_name; }
  
  public void setF_name(String f_name) { this.f_name = f_name; }
  
  
  public String getGender() { return gender; }
  
  public void setGender(String gender) { this.gender = gender; }
  
  public LocalDate getDateOfBirth() { return dateOfBirth; }
  
  public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth
  =dateOfBirth; }
  
  public String getBirth_location() { return birth_location; }
  
  public void setBirth_location(String birth_location) { this.birth_location
  =birth_location; }
  
  public String getAddress() { return address; }
  
  public void setAddress(String address) { this.address = address; }

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getmName() {
	return mName;
}

public void setmName(String mName) {
	this.mName = mName;
}
  
  
  
  
  
  
  
  
  
  
  
  }
 