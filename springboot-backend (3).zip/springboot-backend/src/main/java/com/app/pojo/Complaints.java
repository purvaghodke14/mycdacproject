package com.app.pojo;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonManagedReference;

//import com.fasterxml.jackson.annotation.JsonCreator;

@Entity
@Table(name = "complaints")

public class Complaints {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	/*
	 * @Column(name = "c_name")
	 * 
	 * @NotBlank(message = "name must be supplied") private String name;
	 */

//	@Column(name = "email_id")
//	@NotBlank(message = "email id must be supplied")
//	private String emailId;

	@Column(name = "complaint")
	@NotBlank(message = "data must be provided")
	private String complaint;

	
	@Column(name = "dept_name")
	private String deptName;

	@Column(name = "date")
	private LocalDate compDate;
	
	@ManyToOne (cascade = CascadeType.ALL)
	@JoinColumn(name="c_id",referencedColumnName="id")
	private Citizen citizen;
	
	
	@ManyToOne (cascade = CascadeType.ALL)
	@JoinColumn(name="dept_id",referencedColumnName="id")
	@JsonManagedReference
		private Dept dept;

		public Complaints(){
			super();
		}
		  
	public Complaints(long id,String complaint, String deptName,LocalDate compDate) {
		super();
		this.id = id;
		this.complaint = complaint;
		this.deptName = deptName;
		this.compDate = compDate;
		
	}
	

	public Citizen getCitizen() {
		return citizen;
	}

	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}

	public Dept getDept() {
		return dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public Complaints(Dept d, String complaint,String deptName ,LocalDate compDate) {
		
		this.dept=d;
		this.complaint = complaint;
		this.deptName = deptName;
		this.compDate = compDate;
	}

	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	

	public String getComplaint() {
		return complaint;
	}

	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}

	
	  public String getDeptName()
	  {
		  return deptName;
		  }
	  
	  public void setDeptName(String deptName)
	  { 
		  this.deptName = deptName;
		  }
	  
	 
	public LocalDate getCompDate() {
		return compDate;
	}

	public void setCompDate(LocalDate compDate) {
		this.compDate = compDate;
	}

}
