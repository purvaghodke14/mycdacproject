package com.app.pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="dept")
public class Dept {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="dept_name",length = 100,unique = true)
	private String deptName;
	
	@Column(name="contact_no", length=10)
	private String deptContactNo;
//	
	@OneToMany(mappedBy="dept")  
	@JsonBackReference
	private List<Complaints> complaints;   
	
	public Dept() {
		
	}

	public Dept(long id, String deptName, String deptContactNo) {
		super();
		this.id = id;
		this.deptName = deptName;
		this.deptContactNo = deptContactNo;
	}

	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptContactNo() {
		return deptContactNo;
	}

	public void setDeptContactNo(String deptContactNo) {
		this.deptContactNo = deptContactNo;
	}

	public List<Complaints> getComplaints() {
		return complaints;
	}

	public void setComplaints(List<Complaints> complaints) {
		this.complaints = complaints;
	}

	


	
	
	
	
	
}
