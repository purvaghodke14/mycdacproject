package com.app.pojo;


import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;



@Entity
@Table(name = "property_tax")

public class PropertyTax {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="location")
	@NotBlank
	private String Location;
	
	@Column(name="property_type")
	@NotBlank
	private String type;
	
	@Column(name="value_assessed")
	@NotNull
	private double value;
	
//	@Column(name="date")
//	@NotNull
//	private LocalDate date;
	

	@ManyToOne (cascade = CascadeType.ALL)
	@JoinColumn(name="c_id",referencedColumnName = "id")
	private Citizen citizen;

	
	public PropertyTax( String location,  String type, double value) {
		super();
		this.Location = location;
		this.type = type;
		this.value = value;
		//this.date=date;
	
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	

	public Citizen getCitizen() {
		return citizen;
	}

	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}

//	public LocalDate getDate() {
//		return date;
//	}
//
//	public void setDate(LocalDate date) {
//		this.date = date;
//	}

	
	
	

}
