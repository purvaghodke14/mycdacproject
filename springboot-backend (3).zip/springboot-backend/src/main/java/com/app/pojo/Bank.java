package com.app.pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "bank")
public class Bank {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="citizen_name")
	@NotBlank
	private String name;
	
	@Column(name="bankName")
	@NotBlank
	private String bankName;
	
	@Column(name="branch")
	private String branchName;
	
	@Column(name="cardNumber")
    private long cardNumber;

	@Column(name="amount")
	private long paymentAmount;
	
	@Column(name="date")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate expiryDate;
	
	@Column(name="cvv_num")
		private long cvvNumber;
	
	public Bank() {
		
	}

	public Bank(Long id,String name,String bankName,String branchName, long cardNumber, long paymentAmount,long cvvNumber, LocalDate expiryDate) {
		super();
		this.id = id;
		this.name=name;
		this.bankName = bankName;
		this.branchName=branchName;
		this.cardNumber = cardNumber;
		this.paymentAmount=paymentAmount;
		this.expiryDate = expiryDate;
		this.cvvNumber = cvvNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	
	public long getCvvNumber() {
		return cvvNumber;
	}

	public void setCvvNumber(long cvvNumber) {
		this.cvvNumber = cvvNumber;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public long getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(long paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
