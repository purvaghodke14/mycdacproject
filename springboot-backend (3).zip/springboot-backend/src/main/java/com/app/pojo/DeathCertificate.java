package com.app.pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity

@Table(name="death_certificate") 
public class DeathCertificate {
	
	@Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  	private long id;

@Column(name="deceased_name")
@NotBlank 
private String name;

@Column(name="father_name")
private String f_name;

@Column(name="gender")
@NotBlank 
private String gender;

@Column(name="date_of_death")
 @NotNull 
 private LocalDate dateOfDeath;

@Column(name="death_location")
private String death_location;

@Column(name="permanent_addr")
@NotBlank 
private String address;

@Column(name="age")
private int age;

@Column(name="Nationality")
private String nationality;

@Column(name="religion")
private String religion;


public DeathCertificate() {
	
}

public DeathCertificate(long id, String name, String f_name, String gender, LocalDate dateOfDeath,  String death_location,  String address, int age,
		String nationality, String religion) {
	super();
	this.id = id;
	this.name = name;
	this.f_name = f_name;
	this.gender = gender;
	this.dateOfDeath = dateOfDeath;
	this.death_location = death_location;
	this.address = address;
	this.age = age;
	this.nationality = nationality;
	this.religion = religion;
}

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getF_name() {
	return f_name;
}

public void setF_name(String f_name) {
	this.f_name = f_name;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public LocalDate getDateOfDeath() {
	return dateOfDeath;
}

public void setDateOfDeath(LocalDate dateOfDeath) {
	this.dateOfDeath = dateOfDeath;
}

public String getDeath_location() {
	return death_location;
}

public void setDeath_location(String death_location) {
	this.death_location = death_location;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public String getNationality() {
	return nationality;
}

public void setNationality(String nationality) {
	this.nationality = nationality;
}

public String getReligion() {
	return religion;
}

public void setReligion(String religion) {
	this.religion = religion;
}








}
